<?php
session_start();
if(!isset($_SESSION['id_usuario'])){
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>🎹 Piano Animalitos</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: "Comic Sans MS", cursive, sans-serif; }
    body { font-family: Arial, sans-serif; background: url('imagenes/fondonubes.jpg') center/cover no-repeat; background-attachment: fixed; width: 100vw; min-height: 100vh; display: flex; flex-direction: column; align-items: center; background-color: #fff8f0; padding-bottom: 40px; }
    header { width: 100%; height: 120px; position: relative; background-color: #aadbfc; border-bottom: 3px solid #ff66ff5f; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
    .header-contenido { height: 70%; display: flex; align-items: flex-end; justify-content: center; position: relative; padding-bottom: 10px; }
    .logo img { position: absolute; top: -20px; left: 2px; height: 170px; z-index: 5; }
    .login { position: absolute; right: 20px; bottom: 5px; }
    .login img { height: 60px; cursor: pointer; }
    .titulo { text-align: center; }
    .titulo h1 { margin: 0; font-size: 45px; color: #f20c4697; font-weight: bold; line-height: 1.2; }
    .titulo p { margin: 0; font-size: 20px; color: #003366; line-height: 1.2; }
    .navegacion { display: flex; justify-content: center; gap: 20px; background-color: #f2b8e7e0; padding: 10px; box-shadow: inset 0 1px 4px rgba(0, 0, 0, 0.1); width: 100%; }
    .navegacion a { text-decoration: none; color: #0c0100; font-weight: bold; padding: 6px 12px; border-radius: 6px; }
    .navegacion a:hover { background-color: #ff004875; color: black; }
    .footer { margin-top: 200px; background-color: #aadbfc; text-align: center; padding: 15px; font-size: 14px; color: #333; border-top: 3px solid #FFD966; width: 100%; }
    h1.tit { font-size: 32px; color: #ff6f61; text-shadow: 2px 2px 5px #fff; margin: 30px 0 20px; animation: bounce 2s infinite; text-align: center; }
    @keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
    .piano { display: flex; flex-direction: row; flex-wrap: nowrap; overflow-x: auto; border-radius: 15px; box-shadow: 0 0 20px #888; background-color: #fff3e0; border: 4px solid #ff9800; padding: 10px; gap: 10px; max-width: 90vw; }
    .key { flex: 1 1 100px; height: 140px; text-align: center; font-size: 18px; font-weight: bold; color: white; cursor: pointer; border: none; border-radius: 10px; display: flex; flex-direction: column; justify-content: center; align-items: center; transition: 0.2s; min-width: 100px; }
    .key:hover { transform: scale(1.05); box-shadow: 0 0 10px white; }
    .emoji { font-size: 30px; margin-bottom: 5px; }
    .perro     { background-color: #82363171; }
    .gato      { background-color: #f1c2069c; }
    .vaca      { background-color: #c914a263; }
    .oveja     { background-color: #3f51b5; }
    .pato      { background-color: #00968760; }
    .leon      { background-color: #f9c48bed; }
    .mono      { background-color: #b1701597; }
    .elefante  { background-color: #82c2dd99; }
  </style>
</head>
<body>

  <header>
    <div class="header-contenido">
      <div class="logo">
        <img src="imagenes/panda.png" alt="Logo Peke Kamp">
      </div>
      <div class="titulo">
        <h1>Mundo Curioso</h1>
        <p>¡Descubre, Crea y Juega!</p>
      </div>
      <div class="login" style="text-align: center; margin-top: 15px;">
        <?php if(isset($_SESSION['nombre'])): ?>
            <span style="color: #003366; font-size: 18px; font-weight: bold;">¡Hola, <?= $_SESSION['nombre']; ?>!</span><br>
            <a href="logout.php" style="color: #f20c46; text-decoration: none; font-weight: bold; font-size: 14px;">Cerrar sesión</a>
        <?php else: ?>
            <a href="login.html"><img src="imagenes/sesion.png" alt="Iniciar sesión"></a>
        <?php endif; ?>
      </div>
    </div>
    <nav class="navegacion">
      <a href="canciones.php">Canciones</a>
      <a href="cuentos.php">Cuentos</a>
      <a href="adivinanzas.php">Adivinanzas</a>
    </nav>
  </header>

   <img src="imagenes/logo.png" alt="logo"
     style="position: absolute; left: 30px; top: 65%; transform: translateY(-50%); width: 210px; cursor: pointer;"
     onclick="location.href='juegos.php'">

  <h1 class="tit">🎹 ¡El Piano de los Animalitos! 🐾</h1>

  <div class="piano">
    <button class="key perro" onclick="tocarSonido('perro')"><div class="emoji">🐶</div>Guau</button>
    <button class="key gato" onclick="tocarSonido('gato')"><div class="emoji">🐱</div>Miau</button>
    <button class="key vaca" onclick="tocarSonido('vaca')"><div class="emoji">🐮</div>Muu</button>
    <button class="key oveja" onclick="tocarSonido('oveja')"><div class="emoji">🐑</div>Beee</button>
    <button class="key pato" onclick="tocarSonido('pato')"><div class="emoji">🦆</div>Cuac</button>
    <button class="key leon" onclick="tocarSonido('leon')"><div class="emoji">🦁</div>Grrr</button>
    <button class="key mono" onclick="tocarSonido('mono')"><div class="emoji">🐒</div>Uuh ah</button>
    <button class="key elefante" onclick="tocarSonido('elefante')"><div class="emoji">🐘</div>Bruu</button>
  </div>

  <footer class="footer">
    <p>© 2025 Peke Kamp | Juegos, cuentos y diversión educativa para niños creativos.</p>
  </footer>

  <script>
    function tocarSonido(nombreAnimal) {
      const audio = new Audio('sounds/' + nombreAnimal + '.mp3');
      audio.play().catch(error => {
        alert("❌ No se pudo reproducir el audio de: " + nombreAnimal);
        console.error(error);
      });
    }
  </script>
</body>
</html>