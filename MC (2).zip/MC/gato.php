<?php
session_start();
if(!isset($_SESSION['id_usuario'])){
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gato vs Ratón | Peke Kamp</title>
<style>
*{ margin:0; padding:0; box-sizing:border-box; }
body{ font-family:'Segoe UI',sans-serif; background:url("imagenes/fondonubes.jpg") center/cover fixed; min-height:100vh; }
header{ background:#aadbfc; border-bottom:3px solid #ff66ff5f; box-shadow:0 3px 10px #0003; }
.header-contenido{ height:120px; display:flex; align-items:center; justify-content:center; position:relative; }
.logo img{ position:absolute; left:10px; top:-20px; width:170px; }
.login{ position:absolute; right:20px; }
.login img{ width:60px; }
.titulo{ text-align:center; }
.titulo h1{ color:#f20c4697; font-size:45px; }
.titulo p{ color:#003366; font-size:20px; }
.navegacion{ display:flex; justify-content:center; gap:20px; padding:10px; background:#f2b8e7e0; }
.navegacion a{ color:#0c0100; text-decoration:none; font-weight:bold; padding:8px 15px; border-radius:10px; transition:.3s; }
.navegacion a:hover{ background:#ff004875; color:white; }
.caja{ background:white; width:350px; max-width:90%; margin:50px auto; padding:25px; text-align:center; border-radius:20px; box-shadow:0 10px 25px #0004; }
.caja h2{ color:#d63384; margin-bottom:15px; }
#mensaje{ color:#555; font-size:20px; margin-bottom:15px; }
.tablero{ display:grid; grid-template-columns:repeat(3,90px); justify-content:center; gap:10px; }
.celda{ width:90px; height:90px; border:none; border-radius:15px; background:#FFD700; font-size:45px; cursor:pointer; transition:.2s; }
.celda:hover{ transform:scale(1.08); background:#ffe873; }
.puntos{ display:flex; justify-content:space-around; margin:20px; font-size:20px; font-weight:bold; }
button.reiniciar{ background:#ff69b4; color:white; border:none; padding:12px 25px; border-radius:10px; cursor:pointer; font-size:16px; }
button.reiniciar:hover{ background:#e055a3; }
.footer{ background:#FF69B4; text-align:center; padding:15px; margin-top:40px; }
@media(max-width:600px){ .titulo h1{ font-size:35px; } .logo img{ width:110px; } .tablero{ grid-template-columns:repeat(3,70px); } .celda{ width:70px; height:70px; } }
</style>
</head>
<body>

<header>
  <div class="header-contenido">
    <div class="logo">
      <img src="imagenes/panda.png" alt="Logo Peke Kamp">
    </div>
    <div class="titulo">
      <h1>Mundo Curioso</h1>
      <p>Juego de Gato VS Ratón</p>
    </div>
    <div class="login" style="text-align: center; margin-top: 15px;">
        <?php if(isset($_SESSION['nombre'])): ?>
            <span style="color: #003366; font-size: 18px; font-weight: bold;">¡Hola, <?= $_SESSION['nombre']; ?>!</span><br>
            <a href="logout.php" style="color: #f20c46; text-decoration: none; font-weight: bold; font-size: 14px;">Cerrar sesión</a>
        <?php else: ?>
            <a href="login.html"><img src="imagenes/sesion.png" alt="Iniciar sesión"></a>
        <?php endif; ?>
    </div>
  </div>
  <nav class="navegacion">
    <a href="canciones.php"> Canciones</a>
    <a href="cuentos.php"> Cuentos</a>
    <a href="adivinanzas.php"> Adivinanzas</a>
    <a href="juegos.php"> Volver a Juegos</a>
  </nav>
</header>

<div class="caja">
  <h2>🐱 Gato vs Ratón 🐭</h2>
  <div id="mensaje">Turno de: 🐱</div>
  <div class="tablero" id="tablero"></div>
  <div class="puntos">
    <div>🐱 <span id="gato">0</span></div>
    <div>🐭 <span id="raton">0</span></div>
  </div>
  <button class="reiniciar">Reiniciar</button>
</div>

<footer class="footer">
  © 2025 Mundo Curioso | Juegos, cuentos y diversión educativa
</footer>

<script>
const tableroHTML=document.querySelector("#tablero");
const mensaje=document.querySelector("#mensaje");
const boton=document.querySelector(".reiniciar");
let tablero=["","","","","","","","",""];
let turno="🐱";
let activo=true;
let puntos={"🐱":0, "🐭":0};

const combinaciones=[
  [0,1,2], [3,4,5], [6,7,8], [0,3,6], [1,4,7], [2,5,8], [0,4,8], [2,4,6]
];

for(let i=0;i<9;i++){
  let boton=document.createElement("button");
  boton.className="celda";
  boton.dataset.pos=i;
  tableroHTML.appendChild(boton);
}

document.querySelectorAll(".celda").forEach(celda=>{
  celda.addEventListener("click",()=>{
    let pos=celda.dataset.pos;
    if(tablero[pos]==="" && activo){
      tablero[pos]=turno;
      celda.textContent=turno;
      if(gano()){
        mensaje.textContent=`¡Ganó ${turno}!`;
        puntos[turno]++;
        actualizarPuntos();
        activo=false;
      }
      else if(empate()){
        mensaje.textContent="¡Empate!";
        activo=false;
      }
      else{
        turno=turno==="🐱"?"🐭":"🐱";
        mensaje.textContent="Turno de: "+turno;
      }
    }
  });
});

function gano(){ return combinaciones.some(comb=>{ let[a,b,c]=comb; return tablero[a] && tablero[a]===tablero[b] && tablero[a]===tablero[c]; }); }
function empate(){ return tablero.every(c=>c!==""); }
function actualizarPuntos(){ document.querySelector("#gato").textContent=puntos["🐱"]; document.querySelector("#raton").textContent=puntos["🐭"]; }
boton.addEventListener("click",reiniciar);
function reiniciar(){
  tablero=["","","","","","","","",""];
  document.querySelectorAll(".celda").forEach(c=>c.textContent="");
  turno="🐱"; activo=true; mensaje.textContent="Turno de: 🐱";
}
</script>
</body>
</html>