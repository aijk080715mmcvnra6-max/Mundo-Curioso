<?php
session_start();
if(!isset($_SESSION['id_usuario'])){
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Juego del Memorama</title>
  <style>
    body { font-family: 'Segoe UI', sans-serif; background: url('imagenes/fondonubes.jpg') center/cover no-repeat; background-attachment: fixed; height: 100%; width: 100%; padding: 0; margin: 0; }
    header { height: 120px; position: relative; background-color: #aadbfc; border-bottom: 3px solid #ff66ff5f; box-shadow: 0 2px 5px rgba(0,0,0,0.2); overflow: visible; }
    .header-contenido { height: 70%; display: flex; align-items: flex-end; justify-content: center; position: relative; padding-bottom: 10px; }
    .logo img { position: absolute; top: -20px; left: 2px; height: 170px; z-index: 5; }
    .login { position: absolute; right: 20px; bottom: 5px; }
    .login img { height: 60px; cursor: pointer; }
    .titulo { text-align: center; }
    .titulo h1 { margin: 0; font-size: 45px; color: #f20c4697; font-weight: bold; line-height: 1.2; }
    .titulo p { margin: 0; font-size: 20px; color: #003366; line-height: 1.2; }
    .navegacion { display: flex; justify-content: center; gap: 20px; background-color: #f2b8e7e0; padding: 10px; box-shadow: inset 0 1px 4px rgba(0, 0, 0, 0.1); }
    .navegacion a { text-decoration: none; color: #0c0100; font-weight: bold; padding: 6px 12px; border-radius: 6px; }
    .navegacion a:hover { background-color: #ff004875; color: black; }
    .footer { margin-top: 50px; background-color: #FF69B4; text-align: center; padding: 15px; font-size: 14px; color: #333; border-top: 3px solid #FFD966; }
    
    .container { width: 780px; height: 635px; margin: 20px auto; background-color: white; text-align: center; border-radius:10px; padding-bottom: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);}
    .section1 button { width: 100px; height: 85px; background-color: rgba(29, 142, 223, 0.402); font-size: 50px; color: #333; border: 2px solid #0f4685; cursor: pointer; }
    button#reiniciar { width: 100px; height: 30px; background-color: #733ddd; color: white; border: 1px solid black; border-radius: 10px; cursor: pointer; }
    table { margin: auto; }
    #cabecera { width: 100%; height: 110px; background-color: #8f35f55d; display: flex; text-align: center; justify-content: center; border-radius: 10px 10px 0 0; }
    .memorama { display: flex; margin: 0 auto; align-items: center; width: 460px; }
    .section1 { padding: 0 10px 10px 10px; }
    h1.subt { color: #333; font-size: 25px; text-align: center; }
    #mensaje { font-size: 16px; color: green; text-align: center; }
    #mensaje2 { font-size: 16px; color: red; text-align: center; }
    .m, .e, .m2, .o, .r, .a, .m3, .a2 { font-size: 50px; font-family: Arial black; -webkit-text-stroke: 1px rgb(20, 2, 2); }
    .m { -webkit-text-fill-color: #00bfff37; } .e { -webkit-text-fill-color: #2ecc704d; } .m2 { -webkit-text-fill-color: #F39C12; } .o { -webkit-text-fill-color: #1f519c4a; } .r { -webkit-text-fill-color: #5a5cec5f; } .a { -webkit-text-fill-color: #58419786; } .m3 { -webkit-text-fill-color: #9e17aa4d; } .a2 { -webkit-text-fill-color: #cc6382; }
  </style>
</head>
<body>

  <header>
    <div class="header-contenido">
      <div class="logo">
        <img src="imagenes/panda.png" alt="Logo panda">
      </div>
      <div class="titulo">
        <h1>Mundo Creativo</h1>
        <p>Descubre, Crea y Juega</p>
      </div>
      <div class="login" style="text-align: center; margin-top: 15px;">
        <?php if(isset($_SESSION['nombre'])): ?>
            <span style="color: #003366; font-size: 18px; font-weight: bold;">¡Hola, <?= $_SESSION['nombre']; ?>!</span><br>
            <a href="logout.php" style="color: #f20c46; text-decoration: none; font-weight: bold; font-size: 14px;">Cerrar sesión</a>
        <?php else: ?>
            <a href="login.html"><img src="imagenes/sesion.png" alt="Iniciar sesión"></a>
        <?php endif; ?>
      </div>
    </div>
    <nav class="navegacion">
      <a href="canciones.php">Canciones</a>
      <a href="cuentos.php">Cuentos</a>
      <a href="adivinanzas.php">Adivinanzas</a>
    </nav>
  </header>

<img src="imagenes/LOGO.png" alt="logo"
     style="position: absolute; left: 30px; top: 65%; transform: translateY(-50%); width: 180px; cursor: pointer;"
     onclick="location.href='juegos.php'">
     
  <div class="container">
    <div id="cabecera">
      <p>
        <span class="m">M</span><span class="e">E</span><span class="m2">M</span><span class="o">O</span><span class="r">R</span><span class="a">A</span><span class="m3">M</span><span class="a2">A</span>
      </p>
    </div>
    <div class="memorama">
      <section class="section1">
        <h1 class="subt">MEMORAMA DE ANIMALES</h1>
        <h3 id="mensaje"></h3>
        <h3 id="mensaje2"></h3>
        <table>
          <tr>
            <td><button id="0" onclick="voltear(0)"></button></td>
            <td><button id="1" onclick="voltear(1)"></button></td>
            <td><button id="2" onclick="voltear(2)"></button></td>
            <td><button id="3" onclick="voltear(3)"></button></td>
          </tr>
          <tr>
            <td><button id="4" onclick="voltear(4)"></button></td>
            <td><button id="5" onclick="voltear(5)"></button></td>
            <td><button id="6" onclick="voltear(6)"></button></td>
            <td><button id="7" onclick="voltear(7)"></button></td>
          </tr>
          <tr>
            <td><button id="8" onclick="voltear(8)"></button></td>
            <td><button id="9" onclick="voltear(9)"></button></td>
            <td><button id="10" onclick="voltear(10)"></button></td>
            <td><button id="11" onclick="voltear(11)"></button></td>
          </tr>
          <tr>
            <td><button id="12" onclick="voltear(12)"></button></td>
            <td><button id="13" onclick="voltear(13)"></button></td>
            <td><button id="14" onclick="voltear(14)"></button></td>
            <td><button id="15" onclick="voltear(15)"></button></td>
          </tr>
        </table>
      </section>
      <section class="section2">
        <h2 id="tiempo">Tiempo: 30 segundos</h2>
        <h2 id="puntos">Puntos: 0/100</h2>
      </section>
    </div>
    <button id="reiniciar" onclick="location.reload()" style="visibility: hidden;">Reiniciar</button>
  </div>

  <footer class="footer">
    <p>© 2025 Mundo Creativo | Juegos, cuentos y diversión educativa para niños creativos.</p>
  </footer>

  <script>
  let cartasVolteadas = 0;
  let pares = 0;
  let puntos = 0;
  let temporizador = false;
  let tiempo = 30;
  let tiempoRegresivo = null;
  let carta1 = null; let carta2 = null;
  let primerResultado = ""; let segundoResultado = "";
  let audio = new Audio('sounds/sound1.wav'); let audio2 = new Audio('sounds/perder.wav'); let audio3 = new Audio('sounds/ganar.wav');
  let juegoTerminado = false;
  let mostrarPuntos = document.getElementById('puntos'); let mostrarMensaje = document.getElementById('mensaje'); let mostrarTiempo = document.getElementById('tiempo'); let jugarDenuevo = document.getElementById('reiniciar');
  let sticker = ['🐰','🐰','🐼','🐼','🐷','🐷','🐱','🐱','🦁','🦁','🐶','🐶','🦊','🦊','🐔','🐔'];
  
  sticker.sort(() => Math.random() - 0.5);

  function contarTiempo() {
    tiempoRegresivo = setInterval(() => {
      tiempo--;
      mostrarTiempo.innerHTML = `Tiempo: ${tiempo} ${tiempo === 1 ? "segundo" : "segundos"}`;
      if (tiempo <= 0) { clearInterval(tiempoRegresivo); bloquearCartas(); }
    },1000);
  }

  function bloquearCartas(){
    for(let i = 0; i < 16; i++){
      let carta = document.getElementById(i);
      carta.innerHTML = sticker[i]; carta.disabled = true;
    }
    mostrarMensaje.innerHTML = ""; document.getElementById('mensaje2').innerHTML = "¡SE HA TERMINADO EL TIEMPO!";
    jugarDenuevo.style.visibility = "visible"; audio2.play().catch(()=>{}); juegoTerminado = true;
  }

  function voltear(id){
    if(juegoTerminado) return;
    if(!temporizador){ contarTiempo(); temporizador = true; }
    cartasVolteadas++;

    if(cartasVolteadas === 1){
      carta1 = document.getElementById(id); primerResultado = sticker[id]; carta1.innerHTML = primerResultado; carta1.disabled = true;
    } else if(cartasVolteadas === 2){
      carta2 = document.getElementById(id); segundoResultado = sticker[id]; carta2.innerHTML = segundoResultado; carta2.disabled = true;
      if(primerResultado === segundoResultado){
        cartasVolteadas = 0; pares++; puntos += 12.5; mostrarPuntos.innerHTML = `Puntos: ${puntos}/100`; tiempo += 3; audio.play().catch(()=>{});
      } else {
        setTimeout(()=>{
          carta1.innerHTML = ""; carta2.innerHTML = ""; carta1.disabled = false; carta2.disabled = false; cartasVolteadas = 0;
        },1000);
      }
      if(pares === 8){
        mostrarMensaje.innerHTML = "¡FELICIDADES! HAZ COMPLETADO EL MEMORAMA 🎉";
        clearInterval(tiempoRegresivo); jugarDenuevo.style.visibility = "visible"; audio3.play().catch(()=>{}); juegoTerminado = true;
      }
    }
  }
  </script>
</body>
</html>