<?php
session_start();
if(!isset($_SESSION['id_usuario'])){
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Peke Kamp - Cuentos</title>
  <style>
    body { margin: 0; font-family: Arial, sans-serif; background-image: url('imagenes/fondonubes.jpg'); background-size: cover; background-position: center; }
    header { height: 120px; position: relative; background-color: #aadbfc; border-bottom: 3px solid #ff66ff5f; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
    .header-contenido { height: 70%; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 10px; }
    .logo img { position: absolute; top: -20px; left: 2px; height: 170px; z-index: 5; }
    .login { position: absolute; right: 20px; bottom: 5px; }
    .login img { height: 60px; cursor: pointer; }
    .titulo { text-align: center; }
    .titulo h1 { margin: 0; font-size: 45px; color: #f20c4697; font-weight: bold; }
    .titulo p { margin: 0; font-size: 20px; color: #003366; }
    .navegacion { display: flex; justify-content: center; gap: 20px; background-color: #f2b8e7e0; padding: 10px; box-shadow: inset 0 1px 4px rgba(0, 0, 0, 0.1); }
    .navegacion a { text-decoration: none; color: #0c0100; font-weight: bold; padding: 6px 12px; border-radius: 6px; }
    .navegacion a:hover { background-color: #ff004875; color: black; }
    .juegos { display: flex; flex-direction: column; align-items: center; margin-top: 40px; gap: 20px; }
    .fila { display: flex; gap: 20px; flex-wrap: wrap; justify-content: center; }
    .targeta { width: 150px; height: 250px; cursor: pointer; transition: transform 0.2s; border: 4px solid white; border-radius: 10px; }
    .targeta:hover { transform: scale(1.1); }
    #ver { display: none; text-align: center; margin-top: 40px; }
    #ver img { width: 600px; height: auto; border: 6px solid white; border-radius: 10px; }
    #cerrar { display: block; background: #fff; width: 30px; height: 30px; margin: 15px auto; text-align: center; text-decoration: none; font-size: 25px; color: #000; padding: 5px; border-radius: 50%; line-height: 25px; cursor: pointer; }
    .footer { margin-top: 50px; background-color: #aadbfc; text-align: center; padding: 15px; font-size: 14px; color: #333; border-top: 3px solid #FFD966; }
  </style>
</head>
<body>

  <header>  
    <div class="header-contenido">  
      <div class="logo">  
        <img src="imagenes/panda.png" alt="Logo Peke Kamp">  
      </div>  
      <div class="titulo">  
        <h1>Mundo Curioso</h1>  
        <p>¡Descubre, Crea y Juega!</p>  
      </div>  
      <div class="login" style="text-align: center; margin-top: 15px;">
        <?php if(isset($_SESSION['nombre'])): ?>
            <span style="color: #003366; font-size: 18px; font-weight: bold;">¡Hola, <?= $_SESSION['nombre']; ?>!</span><br>
            <a href="logout.php" style="color: #f20c46; text-decoration: none; font-weight: bold; font-size: 14px;">Cerrar sesión</a>
        <?php else: ?>
            <a href="login.html"><img src="imagenes/sesion.png" alt="Iniciar sesión"></a>
        <?php endif; ?>
      </div>  
    </div>  
    <nav class="navegacion">  
      <a href="canciones.php">Canciones</a>  
      <a href="cuentos.php">Cuentos</a>  
      <a href="adivinanzas.php">Adivinanzas</a>  
    </nav>  
  </header>

   <img src="imagenes/logo.png" alt="logo"
       style="position: absolute; left: 110px; top: 65%; transform: translateY(-50%); width: 300px; cursor: pointer;"
       onclick="location.href='juegos.php'">

  <div class="juegos" id="menu">
    <div class="fila">
      <img src="imagenes/cuento1.jpg" alt="Teresa y El Girasol" class="targeta" onclick="mostrar('imagenes/cuento1.jpg')">
      <img src="imagenes/cocodrilo.jpg" alt="Kiko El Gallo Soñador" class="targeta" onclick="mostrar('imagenes/cocodrilo.jpg')">
      <img src="imagenes/pajarito.jpg" alt="Luna, La Oveja Suavecita" class="targeta" onclick="mostrar('imagenes/pajarito.jpg')">
    </div>
    <div class="fila">
      <img src="imagenes/raton.jpg" alt="Lia, La Jirafa Alta" class="targeta" onclick="mostrar('imagenes/raton.jpg')">
      <img src="imagenes/roman.jpg" alt="Toby, El Amigo Fiel" class="targeta" onclick="mostrar('imagenes/roman.jpg')">
    </div>
  </div>

  <div id="ver">
    <img id="imgGrande" src="">
    <a id="cerrar" onclick="regresar()">×</a>
  </div>

  <footer class="footer">  
    <p>© 2025 Mundo Curioso | Juegos, cuentos y diversión educativa para niños creativos.</p>  
  </footer>  

  <script>
    function mostrar(ruta) {
      document.getElementById('menu').style.display = 'none';
      document.getElementById('imgGrande').src = ruta;
      document.getElementById('ver').style.display = 'block';
    }
    function regresar() {
      document.getElementById('ver').style.display = 'none';
      document.getElementById('menu').style.display = 'flex';
    }
  </script>
</body>
</html>