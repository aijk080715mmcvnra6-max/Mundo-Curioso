// scripts/movsol.js

// Permite arrastrar
function allowDrop(ev) {
    ev.preventDefault();
}

// Guarda el animal que se está arrastrando
function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

// Relación entre las casillas y el animal correcto
const respuestas = {
    0: "Elefante",
    1: "Oveja",
    2: "Jirafa",
    3: "Pollo",
    4: "Leon",
    5: "Mono",
    6: "Caracol",
    7: "Serpiente",
    8: "Cangrejo",
    9: "Cocodrilo",
    10: "Mariposa",
    11: "Medusa",
    12: "Hormiga",
    13: "Pulpo",
    14: "Pez",
    15: "Tortuga"
};

let aciertos = 0;

// Al soltar un animal
function drop(ev) {
    ev.preventDefault();

    const animal = ev.dataTransfer.getData("text");
    const casilla = ev.target.id;

    // Evita colocar dos animales en la misma casilla
    if (ev.target.children.length > 0) {
        alert("⚠️ Esta casilla ya está ocupada.");
        return;
    }

    // Comprueba si es el animal correcto
    if (respuestas[casilla] === animal) {

        ev.target.appendChild(document.getElementById(animal));
        aciertos++;

          // Si termina el juego
        if (aciertos === Object.keys(respuestas).length) {
            setTimeout(function () {
                alert("🎉 ¡Felicidades! ¡Completaste el juego!");
            }, 300);
        }

    } else {

        alert("❌ ¡Ese no es el lugar correcto! Inténtalo nuevamente.");

    }
}